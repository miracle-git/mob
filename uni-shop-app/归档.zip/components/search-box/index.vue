<template>
  <view>
    Search
  </view>
</template>

<script>
  export default {
    name: "search-box",
    data() {
      return {
        
      }
    }
  }
</script>

<style lang="scss">
  @import "./index.scss";
</style>
