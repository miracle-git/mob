import SearchBox from './search-box/index.vue'

export default function(Vue) {
  Vue.component('search-box', SearchBox)
}